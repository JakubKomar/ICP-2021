#include "port.h"

port::port(QObject *parent) : QObject(parent)
{

}
